public class Nodo {
    String Alumno;
    double Calificacion;
    Nodo siguiente;
}
