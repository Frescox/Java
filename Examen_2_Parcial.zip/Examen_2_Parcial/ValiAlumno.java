import java.util.Scanner;

public class ValiAlumno {

    public static Scanner ptr = new Scanner(System.in);

    public static String validaNombre(){// Verifica que solo ingrese letras
        String dato;
        do{
            System.out.println("Ingrese nombre de alumno: "); 
            dato = ptr.nextLine();     
        }while(!Validaciones.soloStr(dato));
        return dato;
    }

    public static String validaCalificacion(String nombre){ // Verifica que solo ingrese numeros menores a 20
        String dato;
        System.out.println("Ingrese calificación de " + nombre + " :");
        dato = ptr.nextLine();
        while(Validaciones.soloStr(dato)|| Double.parseDouble(dato) > 20){ // verifica que solo ingrese letras
                                                                        // y que no sea mayor a 20 (calif max)
            System.out.println("Ingrese solo numeros, además la calificacion maxima es 20.");
            dato = ptr.nextLine();
        }
        return dato;
    }
}
