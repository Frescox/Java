import java.util.Scanner;

public class Validaciones {

    public static Scanner ptr = new Scanner(System.in);


    public static String leeInt() { // Verifica que no este vacio o sean cadena de caracteres
        String dato;
        dato = ptr.nextLine();
        while (strvacio(dato) || !solonums(dato)){ // Continuará pidiendo entrada hasta que no esté vacía
            dato = ptr.nextLine();
        }
        return dato;
    }

    public static boolean strvacio(String dato) {
        return dato.isEmpty(); // Verifica si la cadena está vacía
    }

    public static boolean soloStr(String dato) {
        return dato.matches("[a-zA-Z ]+"); // Verifica si solo contiene letras o espacios
    }

    public static boolean solonums(String dato) {
        return dato.matches("[0-9]+"); // Verifica si solo contiene dígitos numéricos
    }

}
