import java.util.Scanner;

public class Principal{
    public static void main (String [] args){
        Scanner ptr = new Scanner(System.in);
        Pila_y_Cola examenes = new Pila_y_Cola();
        Pila_y_Cola examCola = new Pila_y_Cola();
        Pila_y_Cola ordenCalif = new Pila_y_Cola();
        String opcion = "";
        String nombre, calificacion; 
        do{
        examenes.menu();
        System.out.println("Eliga una opcion: ");
        opcion = Validaciones.leeInt();
        switch(Integer.parseInt(opcion)){
            case 1:
                System.out.println("\nMétodo de ingreso:");
                System.out.println("[1] Ingresar examenes predeterminados");
                System.out.println("[2] Ingresar examen manualmente");
                System.out.println("Eliga una opcion: ");
                opcion = Validaciones.leeInt();
                switch(Integer.parseInt(opcion)){
                    case 1:
                        examenes.insertarPila("Tobias", "8.5", examCola, ordenCalif);
                        examenes.insertarPila("Karla", "9.4", examCola, ordenCalif);
                        examenes.insertarPila("Juan", "6.7", examCola, ordenCalif);
                        examenes.insertarPila("Lucero", "8.9", examCola, ordenCalif);
                        examenes.insertarPila("Oscar", "10", examCola, ordenCalif);
                        System.out.println("\nExamenes recibidos\n");
                    break;
                    case 2: 
                    nombre = ValiAlumno.validaNombre();
                    calificacion = ValiAlumno.validaCalificacion(nombre);
                    examenes.insertarPila(nombre, calificacion, examCola, ordenCalif);
                    break;
                }
            break;
            case 2:
                if(!examenes.vacia()){
                    System.out.println("\nPila:\n");
                    examenes.mostrarPila();
                }
                else{
                    System.out.println("Aún no han entregado examen");
                }
            break;
            case 3: 
                if(!examenes.vacia()){
                    System.out.println("\nCola:\n");
                    examenes.mostrarCola(examCola);;
                }
                else{
                    System.out.println("Aún no han entregado examen");
                }            
            break;
            case 4: 
                if(!examenes.vacia()){
                    System.out.println("\nCalifaciones en orden Decreciente\n");
                    examenes.mostrarOrdenCalif(ordenCalif);
                }
                else{
                    System.out.println("Aún no han entregado examen");
                }
            break;
            case 5:
                if(!examenes.vacia()){
                    System.out.println("\nCalificaciones Finales\n");
                    examenes.mostrarcalifFinales(ordenCalif);
                }
                else{
                    System.out.println("Aún no han entregado examen");
                }
            break;
            case 6:
                System.out.println("Gracias por su tiempo");
            break;
            default:
                System.out.println("Ingrese una de las opciones");
            break;
        }}while(Integer.parseInt(opcion) != 6);

        ptr.close();
    }
}