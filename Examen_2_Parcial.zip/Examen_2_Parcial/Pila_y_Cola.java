public class Pila_y_Cola {

    // Definición de variables de instancia
    public Nodo inicio;
    public Nodo fin;

    // Constructor de la clase
    public Pila_y_Cola(){
        inicio = null;
        fin = null;
    }

    public void menu(){
        System.out.println("\nMENU");
        System.out.println("[1] Ingresar examenes");
        System.out.println("[2] Mostrar Calificaciones (Pila)");
        System.out.println("[3] Mostrar Calificaciones (Cola)");
        System.out.println("[4] Mostrar Calificaciones de mayor a menor");
        System.out.println("[5] Mostrar Calificaciones Finales");
        System.out.println("[6] Salir");
    }

    // Método que inserta un elemento en la cola
    public void insertarPila(String nombre, String calificacion, Pila_y_Cola examOrden, Pila_y_Cola ordenCalif){
        // Se crea un nuevo nodo
        Nodo nuevo = new Nodo();
        nuevo.Alumno = nombre; // Asigna el nombre al nodo
        double calif = Double.parseDouble(calificacion);
        nuevo.Calificacion = calif; // Asigna la calificación al nodo
        nuevo.siguiente = null;
        // Inserta en la pila de calificaciones
        examOrden.insertarCola(nombre, calif, ordenCalif);
        // Inserta en la cola
        if(inicio == null){
            inicio = nuevo;
            fin = nuevo;
        }
        else{
            nuevo.siguiente = inicio;
            inicio = nuevo;
        }
    } 

    // Método que inserta un elemento en la pila
    public void insertarCola(String nombre, double calificacion, Pila_y_Cola ordenCalif){
        // Se crea un nuevo nodo
        Nodo nuevo = new Nodo();
        nuevo.Alumno = nombre; // Asigna el nombre al nodo
        nuevo.Calificacion = calificacion; // Asigna la calificación al nodo
        nuevo.siguiente = null;
        // Inserta en la pila de calificaciones ordenadas
        ordenCalif.insertarOrdenCalif(nombre, calificacion);
        // Inserta en la pila
        if(inicio == null){
            inicio = nuevo;
            fin = nuevo;
        }
        else{
            fin.siguiente = nuevo;
            fin = nuevo;
        }
    } 

    // Método que inserta un elemento en la pila de calificaciones ordenadas
    public void insertarOrdenCalif(String nombre, double calificacion){
        // Se crea un nuevo nodo
        Nodo nuevo = new Nodo();
        nuevo.Alumno = nombre;
        nuevo.Calificacion = calificacion;
        nuevo.siguiente = null;
        // Inserta en la pila de calificaciones ordenadas
        if (inicio == null || calificacion > inicio.Calificacion) {
            nuevo.siguiente = inicio;
            inicio = nuevo;
        } else {
            Nodo actual = inicio;
            while (actual.siguiente != null && calificacion <= actual.siguiente.Calificacion) {
                actual = actual.siguiente;
            }
            nuevo.siguiente = actual.siguiente;
            actual.siguiente = nuevo;
            if (nuevo.siguiente == null) {
                fin = nuevo;
            }
        }
    }
    
    public void mostrarPila(){// Muestra todas las calificaciones en forma de pila
            Nodo aux = inicio;
            while(aux != null){ 
                System.out.println(aux.Alumno + " -> Calificación: " + aux.Calificacion);
                aux = aux.siguiente;
            }
    }

    public void mostrarCola(Pila_y_Cola examCola){ // Muestra las calificaciones en forma de cola
        Nodo aux = examCola.inicio;
        while(aux != null){
            System.out.println(aux.Alumno + " -> Calificación: " + aux.Calificacion);
            aux = aux.siguiente;
        }
    }

    public void mostrarOrdenCalif(Pila_y_Cola ordenCalif){// Muestra todas las calificaciones de mayor a menor sin puntos extras
        Nodo aux = ordenCalif.inicio;
        while(aux != null){
            System.out.println(aux.Alumno + " -> Calificación: " + aux.Calificacion);
            aux = aux.siguiente;
        }
    }

    public void mostrarcalifFinales(Pila_y_Cola ordenCalif){// Muestra las calificaciones con puntos extras
            Nodo aux = ordenCalif.inicio;
            aux.Calificacion += 3; // Se le suman 3 puntos a la calificación máxima
            if(aux.siguiente != null){
                aux.siguiente.Calificacion += 2;}// Se le suman 2 puntos a la segunda calificación máxima
            while(aux != null){
                System.out.println(aux.Alumno + " -> Calificación: " + aux.Calificacion);
                aux = aux.siguiente;
            }
            aux = ordenCalif.inicio; // Restablece las calificaciones originales
            aux.Calificacion -= 3; // Restablece las calificaciones originales
            if(aux.siguiente != null){
                aux.siguiente.Calificacion -= 2;}
    }

    // Método para verificar si la pila o la cola está vacía
    public boolean vacia(){
        return inicio == null;
    }
}
